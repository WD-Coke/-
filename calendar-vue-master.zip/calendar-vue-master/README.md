# calendar-vue

> 移动端自适应日历组件--mykurisu

结合博文内容写的小demo，希望对萌新们有所帮助，希望dalao们轻拍

如果大家有兴趣了解其它的话可以到我在掘金的主页-->[传送门](https://juejin.im/user/57ea9ad40e3dd9005838300d/posts)

## 食用方法
```bash
npm install
npm run dev
```
